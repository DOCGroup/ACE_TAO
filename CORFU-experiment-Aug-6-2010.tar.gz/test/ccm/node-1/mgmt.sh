#!/bin/bash
export NSPORT=45454
export NSHOST=`hostname`
HOST=`hostname`
ROLE=1

echo starting NameService ...
$TAO_ROOT/orbsvcs/Naming_Service/Naming_Service -ORBEndpoint iiop://$NSHOST:$NSPORT -o ns.ior &

sleep 1

echo starting ReplicationManager...
$TAO_ROOT/orbsvcs/LWFT_Service/ReplicationManager \
  -ORBInitRef NameService=corbaloc:iiop:$NSHOST:$NSPORT/NameService \
  -use_ns \
  -hm_ior file://hm-$HOST.ior \
  -proc_id ReplicationManager-$HOST \
  -role $ROLE \
  -debug 3 &

sleep 1

echo starting host_monitor...
$TAO_ROOT/orbsvcs/LWFT_Service/HostMonitor -load_mon_freq 10 -rm_update_freq 1 -ior_file hm-$HOST.ior -util_file util-$HOST.dat -rm_name ReplicationManager -ORBInitRef NameService=corbaloc:iiop:$NSHOST:$NSPORT/NameService &

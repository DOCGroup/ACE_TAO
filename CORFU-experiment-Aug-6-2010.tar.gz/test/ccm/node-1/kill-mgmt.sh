killall ReplicationManager
killall Naming_Service
rm *.ior *.dat *~
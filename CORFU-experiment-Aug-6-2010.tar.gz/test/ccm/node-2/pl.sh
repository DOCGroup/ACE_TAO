export DANCE_TRACE_ENABLE=10
$CIAO_ROOT/DAnCE/tests/CIAO/FaultTolerance-Deployments/simple_nm_launcher file://./nm.ior tasks.cdp
#!/bin/bash
export HOST=`hostname`
export EXPERIMENT=`cat /var/emulab/boot/nickname | awk -F '.' '{ printf "%s", $2 }'`
export NSPORT=45454
export NSHOST=node-1.$EXPERIMENT.f6.isislab.vanderbilt.edu

echo starting host_monitor...
$TAO_ROOT/orbsvcs/LWFT_Service/HostMonitor -load_mon_freq 10 -rm_update_freq 1 -ior_file hm-$HOST.ior -util_file util-$HOST.dat -rm_name ReplicationManager -ORBInitRef NameService=corbaloc:iiop:$NSHOST:$NSPORT/NameService &

sleep 1

echo starting Node_Manager...
$CIAO_ROOT/DAnCE/bin/dance_node_manager -n FTNode=nm.ior -s $CIAO_ROOT/bin/ciao_ft_componentserver --server-args "-host_id $NSHOST -hm_ior file://hm-$HOST.ior -ORBInitRef NameService=corbaloc:iiop:$NSHOST:$NSPORT/NameService -debug 2" &

sleep 1

echo launching Deployment... 
$CIAO_ROOT/DAnCE/tests/CIAO/NodeManager-Deployments/simple_nm_launcher file://./nm.ior server.cdp -m
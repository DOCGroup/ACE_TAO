killall dance_node_manager
killall ciao_ft_componentserver
killall HostMonitor
rm *.dat *~ # *.ior
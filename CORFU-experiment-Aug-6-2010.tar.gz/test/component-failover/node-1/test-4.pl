eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

$turns = $ARGV[0];
$testname = "2comp";

for my $i (0 .. $turns)
{
    system ("./deploy.pl Alpha Beta");
    system ("./trigger.pl $testname-$i Alpha Beta");
}

#!/bin/bash
export CIAO_TRACE_ENABLE=1
#export CIAO_LOG_LEVEL=10
#export DANCE_TRACE_ENABLE=1
#export DANCE_LOG_LEVEL=10
export HOST=`hostname | awk -F '.' '{ printf "%s", $1}'`
#export HOST=`hostname`
export EXPERIMENT=`cat /var/emulab/boot/nickname | awk -F '.' '{ printf "%s", $2 }'`
export NSPORT=45454
export NSHOST=node-1
export NSREF=file://../node-1/ns.ior

echo starting dance_node_manager...
$CIAO_ROOT/DAnCE/bin/dance_node_manager -n $HOST=nm.ior -s $CIAO_ROOT/bin/ciao_ft_componentserver --server-args "-host_id `hostname` -hm_ior file://hm-$HOST.ior -ORBInitRef NameService=$NSREF -ORBEndpoint iiop://`hostname`" -ORBInitRef NameService=$NSREF --domain-nc corbaloc:rir:/NameService --instance-nc corbaloc:rir:/NameService
#$CIAO_ROOT/DAnCE/bin/dance_node_manager -n $HOST=nm.ior -s $CIAO_ROOT/bin/ciao_ft_componentserver --server-args "-host_id $HOST -hm_ior file://hm-$HOST.ior -ORBInitRef NameService=$NSREF -ORBEndpoint iiop://$HOST" -ORBInitRef NameService=$NSREF --domain-nc corbaloc:rir:/NameService --instance-nc corbaloc:rir:/NameService

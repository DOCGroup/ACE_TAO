eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

$turns = $ARGV[0];

for ($i = 0; $i < $turns; ++$i)
{
    system ("./deploy.pl Alpha Beta Gamma Delta Zeta Epsilon Phi");
    system ("./trigger.pl $i Alpha Beta Gamma Delta Zeta Epsilon Phi");
}

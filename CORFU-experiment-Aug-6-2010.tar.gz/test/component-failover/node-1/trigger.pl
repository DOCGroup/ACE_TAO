eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

use lib "$ENV{ACE_ROOT}/bin";
use PerlACE::TestTarget;

$hostname = `hostname`;
chomp $hostname;
# extract name before first dot and use it
$hostname =~ /(^.*?)\..*/;
$host = $1;
$port = shift (@ARGV);
$ns_connection = "node-1.flare-f6.f6.isislab.vanderbilt.edu:".$port."/NameService";
$ns_endpoint = "iiop://$ns_connection";
$ns_initref = "-ORBInitRef NameService=$ns_endpoint";
$hmior = "hm-$host.ior";
$app_counter = 0;

@triggers = ();

sub start_trigger
{
    my $prefix = $_[0];
    my $clientname = $_[1];
    my $clientior = "corbaname:iiop:$ns_connection#FLARE_TESTAPPLICATION/" . $clientname . "Client";
    my $trigger = PerlACE::TestTarget::create_target (++$app_counter) || die "creating Worker target failed\n";

#my $TRIGGER = $trigger->CreateProcess ("$ENV{DANCE_ROOT}/tests/CIAO/FTComponents/client_trigger", "$ns_initref -k $clientior -n $count");
    my $TRIGGER = $trigger->CreateProcess("$ENV{DANCE_ROOT}/tests/CIAO/FTComponents/client_trigger", "$ns_initref  $prefix  $clientior");
    
    print "start trigger for $clientname ...\n";

    my $trigger_status = $TRIGGER->Spawn ();

    push (@triggers, $TRIGGER);
}

$prefix = shift (@ARGV);

foreach my $app (@ARGV)
{
        start_trigger ($prefix, $app);
}

foreach my $tr (@triggers)
{
    $tr->Wait ();
    $tr->Kill ();

    print "trigger finished ...\n";
}

eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

$testname = $ARGV[0];
$turns = $ARGV[1];

for my $i (1 .. $turns)
{
    system ("./deploy.pl Alpha Beta Gamma Delta");
    system ("./trigger.pl $testname-$i Alpha Beta Gamma Delta");
    sleep 40;
}

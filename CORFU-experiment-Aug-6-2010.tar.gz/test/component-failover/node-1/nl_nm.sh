#!/bin/bash
export HOST=`hostname | awk -F '.' '{ printf "%s", $1}'`
export HOSTNAME=`hostname`
export EXPERIMENT=`cat /var/emulab/boot/nickname | awk -F '.' '{ printf "%s", $2 }'`
export NSREF=file://../node-1/ns.ior

echo starting Node_Manager...
$CIAO_ROOT/DAnCE/bin/dance_node_manager -c $NSREF -n $HOSTNAME=nm.ior -s $CIAO_ROOT/bin/ciao_ft_componentserver --server-args "-host_id $HOSTNAME -hm_ior file://hm-$HOSTNAME.ior -ORBInitRef NameService=$NSREF -debug 3" -ORBInitRef NameService=$NSREF --domain-nc corbaloc:rir:/NameService --instance-nc corbaloc:rir:/NameService
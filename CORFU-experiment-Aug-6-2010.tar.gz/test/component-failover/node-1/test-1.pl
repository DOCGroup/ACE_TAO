eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

$turns = $ARGV[0];

for ($i = 0; $i < $turns; ++$i)
{
    system ("./deploy.pl Alpha-1 Alpha-2 Alpha-client Beta-1 Beta-2 Beta-client Gamma-1 Gamma-2 Gamma-client");
    system ("./trigger.pl $i Alpha Beta Gamma");
}

eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

use lib "$ENV{ACE_ROOT}/bin";
use PerlACE::TestTarget;

$hostname = `hostname`;
chomp $hostname;
# extract name before first dot and use it
$hostname =~ /(^.*?)\..*/;
$host = $1;
$ns_endpoint = "iiop://node-1.flare-no-lan.f6.isislab.vanderbilt.edu:45452";
$ns_initref = "-ORBInitRef NameService=$ns_endpoint/NameService";
$debug = "";

my $hmior = "hm-$host.ior";
my $nmior = "nm.ior";

my $nm = PerlACE::TestTarget::create_target (1) || die "creating ComponentServer target failed\n";

my $nm_iorfile = $nm->LocalFile ($nmior);

$nm_exec = "$ENV{DANCE_ROOT}/bin/dance_node_manager";

$nm_args ="$ns_initref ";
$nm_args .= "-c $ns_endpoint/NameService -n $hostname=nm.ior ";
$nm_args .= "-s $ENV{CIAO_ROOT}/bin/ciao_ft_componentserver ";
$nm_args .= "--server-args \"$ns_initref -host_id $host -hm_ior file://$hmior -debug 3\" ";
$nm_args .= "--domain-nc corbaloc:rir:/NameService --instance-nc corbaloc:rir:/NameService";

$NM = $nm->CreateProcess ($nm_exec,
                          $nm_args);

print "start ComponentServer ...\n";
print "$nm_exec $nm_args\n";

$nm_status = $NM->Spawn ();

if ($nm->WaitForFileTimed ($nmior,
                           $nm->ProcessStartWaitInterval ()) == -1) {
    print STDERR "ERROR: ComponentServer did not create file <$nmior>\n";
    $NM->Kill (); $NM->TimedWait (1);
    exit 1;
}

$NM->Wait ();
$NM->Kill ();

$nm->DeleteFile ($nmior);

print "ComponentServer finished.\n";

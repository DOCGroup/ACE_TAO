eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

use lib "$ENV{ACE_ROOT}/bin";
use PerlACE::TestTarget;

$hmnodecount = 3;
$nmnodecount = 3;
$hostname = `hostname`;
chomp $hostname;
# extract name before first dot and use it
$hostname =~ /(^.*?)\..*/;

#if ($1)
#{
#    $host = $1;
#}
#else
#{
    $host = $hostname;
#}

print "HOST=$host\n";

$ns_endpoint = "iiop://$hostname:45454";

print "$ns_endpoint\n";
#$ns_initref = "-ORBInitRef NameService=$ns_endpoint/NameService";
$ns_initref = "-ORBInitRef NameService=file://../node-1/ns.ior";
$debug = "-debug 3";
$common_args = "$ns_initref $debug";
$experiment = `cat /var/emulab/boot/nickname`;
chomp $experiment;
$experiment =~ /\.(.*)\./;
$experiment = $1;

@remote_hosts;
@targets;
@remote_hms;

$target_count = 4;

my $nsior = "ns.ior";
my $rmior = "rm.ior";
my $hmior = "hm-$host.ior";
my $hmutil = "hm-$host-util.dat";

my $ns = PerlACE::TestTarget::create_target (1) || die "creating Name_Service target failed\n";
my $rm = PerlACE::TestTarget::create_target (2) || die "creating ReplicationManager target failed\n";
my $hm = PerlACE::TestTarget::create_target (3) || die "creating HostMonitor target failed\n";

my $ns_iorfile = $ns->LocalFile ($nsior);
my $rm_iorfile = $rm->LocalFile ($rmior);
my $rm_hm_ior = $rm->LocalFile ($hmior);
my $hm_iorfile = $hm->LocalFile ($hmior);
my $hm_utilfile = $hm->LocalFile ($hmutil);

$ns->DeleteFile ($nsior);
$rm->DeleteFile ($rmior);
$hm->DeleteFile ($hmior);
$hm->DeleteFile ($hmutil);

$NS = $ns->CreateProcess ("$ENV{TAO_ROOT}/orbsvcs/Naming_Service/Naming_Service",
                          "-ORBEndpoint $ns_endpoint -o $nsior");

$RM = $rm->CreateProcess ("$ENV{TAO_ROOT}/orbsvcs/LWFT_Service/ReplicationManager",
                          "$common_args -use_ns -hm_ior file://$hmior -proc_id ReplicationManager-$host " .
                          "-role 1");

$HM = $hm->CreateProcess ("$ENV{TAO_ROOT}/orbsvcs/LWFT_Service/HostMonitor",
                          "$ns_initref -load_mon_freq 10 -rm_update_freq 1 -ior_file $hmior -util_file $hmutil -rm_name ReplicationManager -logging 1");

my $emior = "EM.ior";
my $em = PerlACE::TestTarget::create_target ($target_count++) || die "creating Name_Service target failed\n";
my $em_iorfile = $em->LocalFile ($emior);
$em->DeleteFile ($emior);

$EM = $em->CreateProcess ("$ENV{DANCE_ROOT}/bin/dance_execution_manager",
                          "$ns_initref -e$emior --domain-nc corbaloc:rir:/NameService");

my $fcmior = "EM.ior";
my $fcm = PerlACE::TestTarget::create_target ($target_count++) || die "creating FaulCorrelationManager target failed\n";
my $fcm_iorfile = $fcm->LocalFile ($fcmior);
$fcm->DeleteFile ($fcmior);

$FCM = $fcm->CreateProcess ("$ENV{DANCE_ROOT}/bin/fcm",
                            "$ns_initref --rep-mgr corbaname:rir:/NameService#ReplicationManager " .
                            "--exec-mgr file://$emior --ior-file $fcmior");

sub start_remote_hm
{
    my $remotenode = "node-$_[0]";
    my $remhm_ior = "hm-$remotenode.ior";
    my $remhm = PerlACE::TestTarget::create_target ($target_count++) || die "creating Name_Service target failed\n";
    my $remote_ior = $remhm->LocalFile ("../$remotenode/$remhm_ior");
    my $util_file = $remhm->LocalFile ("../$remotenode/$remotenode-util.dat");

    $remhm->DeleteFile ("../$remotenode/$remhm_ior");

    $REMHM = $remhm->CreateProcess ("/usr/bin/ssh",
                                    "$remotenode.$experiment.f6.isislab.vanderbilt.edu " .
                                    "\". ftciao.sh && cd $ENV{EXP_ROOT}/calibration/$remotenode " .
                                    "&& $ENV{TAO_ROOT}/orbsvcs/LWFT_Service/HostMonitor -logging 1 " .
                                    "-load_mon_freq 10 -rm_update_freq 1 -ior_file $remhm_ior " .
                                    "-util_file util-$remotenode.dat -rm_name ReplicationManager " .
                                    "$ns_initref -port_range_begin 7000\"");

    print "start remote HostMonitor on node $remotenode ...\n";

    $REMHM->Spawn ();
 
    push (@remote_hosts, $remotenode);
    push (@targets, $remhm);
    push (@remote_hms, $REMHM);
}

@nmnodes = ();
@nmtargets = ();
@nodemgrs = ();

sub start_node_manager
{
    my $node = "node-$_[0]";
    my $ior = "nm.ior";
    my $nm = PerlACE::TestTarget::create_target ($target_count++) || 
        die "creating NodeManager for $node failed\n";
    my $ior_file = $nm->LocalFile ("../$node/$ior");

    $nm->DeleteFile ("../$node/$ior");

    $NM = $nm->CreateProcess ("/usr/bin/ssh",
                              "$node.$experiment.f6.isislab.vanderbilt.edu " .
                              "\". ftciao.sh && cd $ENV{EXP_ROOT}/calibration/$node " .
                              "&& ../node-1/nm.sh\"");

    print "start remote NodeManager on node $node ...\n";

    $NM->Spawn ();
 
    push (@nmtargets, $nm);
    push (@nodemgrs, $NM);
}

sub kill_processes
{
   for ($i = 0; $i < @nodemgrs; ++$i)
    {
        print "stop NodeManager on node $nmnodes[$i] ...\n";

        $nodemgrs[$i]->Kill ();
        $nmtargets[$i]->DeleteFile ("../$nmnodes[$i]/nm.ior");
    }

    $em_status = $EM->Kill ();
    $EM->Wait ();
    $em->DeleteFile ($emior);

    print "stopped ExecutionManager.\n";


    $hm_status = $HM->Kill ();
    $HM->Wait ();
    $hm->DeleteFile ($hmior);
    $hm->DeleteFile ($hmutil);

    print "stopped HostMonitor.\n";
    
    for ($i = 0; $i < @remote_hosts; ++$i)
    {
        print "stop HostMonitor on node $remote_hosts[$i] ...\n";

        $remote_hms[$i]->Kill ();
        $targets[$i]->DeleteFile ("../$remote_hosts[$i]/hm-$remote_hosts[$i].ior");
        $targets[$i]->DeleteFile ("../$remote_hosts[$i]/util-$remote_hosts[$i].dat");
    }

    $rm_status = $RM->Kill ();
    $RM->Wait ();
    $rm->DeleteFile ($rmior);

    print "stopped ReplicationManager.\n";

    $ns_status = $NS->Kill ();
    $NS->Wait ();
    $ns->DeleteFile ($nsior);

    print "stopped Name_Service.\n";
}

print "start Name_Service ...\n";

$ns_status = $NS->Spawn ();

if ($ns->WaitForFileTimed ($nsior,
                           $ns->ProcessStartWaitInterval ()) == -1) {
    print STDERR "ERROR: Name_Service did not create file <$nsior>\n";
    $NS->Kill (); $NS->TimedWait (1);
    exit 1;
}

print "start ReplicationManager ...\n";

$rm_status = $RM->Spawn ();

if ($rm->WaitForFileTimed ($rmior,
                           $rm->ProcessStartWaitInterval ()) == -1) {
    print STDERR "ERROR: Name_Service did not create file <$nsior>\n";
    $RM->Kill (); $RM->TimedWait (1);
    exit 1;
}

sleep 2;

print "start HostMonitor ...\n";

$hm_status = $HM->Spawn ();

if ($hm->WaitForFileTimed ($hmior,
                           $hm->ProcessStartWaitInterval ()) == -1) {
    print STDERR "ERROR: HostMonitor did not create file <$hmior>\n";
    $HM->Kill (); $HM->TimedWait (1);
    exit 1;
}

for ($count = 2; $count < 2 + $hmnodecount; ++$count)
{
    start_remote_hm ($count);
}

sleep 2;

for ($count = 2; $count < 2 + $nmnodecount; ++$count)
{
    start_node_manager ($count);
}

print "start ExecutionManager ...\n";

$EM->Spawn ();

if ($em->WaitForFileTimed ($emior,
                           $em->ProcessStartWaitInterval ()) == -1) {
    print STDERR "ERROR: ExecutionManager did not create file <$emior>\n";
    $EM->Kill (); $EM->TimedWait (1);
    exit 1;
}
 
$input = <>;

kill_processes ();

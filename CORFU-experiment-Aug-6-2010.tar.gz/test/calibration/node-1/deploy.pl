eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

use lib "$ENV{ACE_ROOT}/bin";
use PerlACE::TestTarget;

$hostname = `hostname`;
chomp $hostname;
# extract name before first dot and use it
$hostname =~ /(^.*?)\..*/;
$host = $1;
#$ns_endpoint = "iiop://node-1.flare-no-lan.f6.isislab.vanderbilt.edu:45452";
#$ns_initref = "-ORBInitRef NameService=$ns_endpoint/NameService";
$ns_initref = "-ORBInitRef NameService=file://../node-1/ns.ior";
$debug = "";
$emior = "EM.ior";

sub deploy_plan
{
    my $plan = $_[0];
    my $pl = PerlACE::TestTarget::create_target (1) || die "creating plan launcher target for plan $plan failed\n";
    my $PL = $pl->CreateProcess ("$ENV{DANCE_ROOT}/bin/dance_plan_launcher",
                                 "--em-ior file://$emior --read-plan $plan");

    print "starting plan $plan ...\n";

    $PL->Spawn ();

    $PL->Wait ();
    $PL->Kill ();

    print "plan $plan deployed.\n";
}

foreach $cdp (@ARGV)
{
    deploy_plan ("$cdp.cdp");
}

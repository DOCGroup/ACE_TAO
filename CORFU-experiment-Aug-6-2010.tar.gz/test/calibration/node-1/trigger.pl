eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

use lib "$ENV{ACE_ROOT}/bin";
use PerlACE::TestTarget;

$hostname = `hostname`;
chomp $hostname;
# extract name before first dot and use it
$hostname =~ /(^.*?)\..*/;
$host = $1;
$ns_connection = "node-1:45454/NameService";
$ns_endpoint = "iiop://$ns_connection";
$ns_initref = "-ORBInitRef NameService=$ns_endpoint";
$hmior = "hm-$host.ior";
$app_counter = 0;

@triggers = ();

sub start_trigger
{
    my @clients = split (' ', $_[0]);
    my @iors = ();
    
    foreach $client (@clients)
    {
        my $clientior = "file://../node-3/" . $client . "Client.ior";
        push (@iors, $clientior);
    };

    my $count = $_[1];

    my $trigger = PerlACE::TestTarget::create_target (++$app_counter) || die "creating Worker target failed\n";

    my $iorstrings = join (' ', @iors);
    print "start trigger for $iorstrings ...\n";
    my $TRIGGER = $trigger->CreateProcess ("$ENV{DANCE_ROOT}/tests/CIAO/FTComponents/client_trigger",
                                           "$ns_initref $count $iorstrings");
    
    my $trigger_status = $TRIGGER->Spawn ();

    push (@triggers, $TRIGGER);
}

$counter = shift (@ARGV);

start_trigger (join(' ', @ARGV), $counter);

foreach my $tr (@triggers)
{
    $tr->Wait ();
    $tr->Kill ();

    print "trigger finished ...\n";
}

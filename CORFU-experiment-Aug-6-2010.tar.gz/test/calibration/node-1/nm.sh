#!/bin/bash
export HOST=`hostname | awk -F '.' '{ printf "%s", $1}'`
#export HOST=`hostname`
export EXPERIMENT=`cat /var/emulab/boot/nickname | awk -F '.' '{ printf "%s", $2 }'`
export NSPORT=45454
export NSHOST=node-1
export NSREF=file://../node-1/ns.ior

echo starting Node_Manager...
$CIAO_ROOT/DAnCE/bin/dance_node_manager -n $HOST=nm.ior -s $CIAO_ROOT/bin/ciao_ft_componentserver --server-args "-host_id $HOST -hm_ior file://hm-$HOST.ior -ORBInitRef NameService=$NSREF -ORBEndpoint iiop://$HOST -debug 0" -ORBInitRef NameService=$NSREF --domain-nc corbaloc:rir:/NameService --instance-nc corbaloc:rir:/NameService
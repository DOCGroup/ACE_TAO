eval '(exit $?0)' && eval 'exec perl -S $0 ${1+"$@"}'
    & eval 'exec perl -S $0 $argv:q'
    if 0;

# -*- perl -*-
#
# $Id$

$number = $ARGV[0];

system ("./deploy.pl calibrate$number");
sleep 2;
system ("./trigger.pl calibrate$number Calibrate$number");

